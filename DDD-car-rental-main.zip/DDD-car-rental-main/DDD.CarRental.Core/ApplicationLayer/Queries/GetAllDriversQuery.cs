﻿namespace DDD.CarRental.Core.ApplicationLayer.Queries
{
    public class GetAllDriversQuery
    {
    }
}
