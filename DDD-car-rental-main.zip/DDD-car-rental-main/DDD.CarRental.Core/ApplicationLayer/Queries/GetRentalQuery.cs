﻿namespace DDD.CarRental.Core.ApplicationLayer.Queries
{
    public class GetRentalQuery
    {
        public long RentalID { get; set; }
    }
}
