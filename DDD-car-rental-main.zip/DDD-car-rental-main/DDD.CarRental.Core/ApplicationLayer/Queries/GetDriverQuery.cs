﻿namespace DDD.CarRental.Core.ApplicationLayer.Queries
{
    public class GetDriverQuery
    {
        public long DriverId { get; set; }
    }
}
