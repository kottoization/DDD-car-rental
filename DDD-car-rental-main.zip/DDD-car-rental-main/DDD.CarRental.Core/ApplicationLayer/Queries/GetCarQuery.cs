﻿namespace DDD.CarRental.Core.ApplicationLayer.Queries
{
    public class GetCarQuery
    {
        public long CarID { get; set; }
    }
}
