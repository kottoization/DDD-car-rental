﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DDD.CarRental.Core.ApplicationLayer.Mappers
{
    public class Mapper
    {
        // ToDo: zaimplementwać mapery obiektów biznesowych na transferowe
    }
}
